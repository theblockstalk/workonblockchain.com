import { Component, OnInit } from '@angular/core';
import {UserService} from '../user.service';
import {User} from '../Model/user';
import { HttpClient } from '@angular/common/http';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.css']
})
export class ChatComponent implements OnInit {

	log = '';
	currentUser: User;
	type = 'candidate';
	credentials: any = {};
	users = '';
	msgs = '';
	new_msgs = '';
	display_list = 0;
  constructor(
	private authenticationService: UserService
  ) { }

  ngOnInit() {
	  this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
	    if(this.currentUser.type=="company"){
		  console.log(this.currentUser);
		  console.log('company');
		  this.display_list = 1;
		  this.authenticationService.getCandidate(this.type)
			.subscribe(
				data => {
					console.log('data');
					this.users = data['users'];
				},
				error => {
					console.log('error');
					console.log(error);
					this.log = error;
				}
			);
	    }
		else{
			this.authenticationService.get_user_messages(this.currentUser._creator)
			.subscribe(
				data => {
					console.log('data');
					console.log(data['datas']);
					this.msgs = data['datas'];
					this.credentials.id = data['datas'][0].company_id;
					//this.users = data['users'];
				},
				error => {
					console.log('error');
					console.log(error);
					//this.log = error;
				}
			);
			this.display_list = 0;
			console.log('candidate');
		}
  }
  
  send_message(msgForm : NgForm){
	  if(this.credentials.msg_body && this.credentials.id){
		  console.log(this.credentials.msg_body);
		  this.msgs = this.msgs+ "\n"+ this.credentials.msg_body;
		  //console.log(this.msgs);
		  this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
		  this.authenticationService.insertMessage(this.credentials.id,this.currentUser._id,this.credentials.msg_body)
			.subscribe(
				data => {
					console.log(data);
					this.credentials.msg_body = '';
				},
				error => {
					console.log('error');
					console.log(error);
					//this.log = error;
				}
			);
	  }
	  
  }
  send_message_candidate(msgForm1 : NgForm){
	  //console.log(this.credentials);
	  this.new_msgs = this.new_msgs+ "\n"+ this.credentials.msg_body;
	  this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
	  //console.log(this.currentUser);
	  this.authenticationService.insertMessage(this.currentUser._creator,this.credentials.id,this.credentials.msg_body)
		.subscribe(
			data => {
				console.log(data);
				this.credentials.msg_body = '';
			},
			error => {
				console.log('error');
				console.log(error);
				//this.log = error;
			}
		);
  }
  
  openDialog(email: string, id:string){
	  //this.msgs = 'hi baby';
	  this.msgs = '';
	  this.credentials.email = email;
	  this.credentials.id = id;
	  console.log(id);
  }

}
